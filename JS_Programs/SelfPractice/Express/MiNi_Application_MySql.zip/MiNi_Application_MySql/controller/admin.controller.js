import pool from "../db/dbConfig.js";

export const singInPage = (request, response, next) => {
  return response.render("signin.ejs");
}

export const signUp = (request, response) => {
  let { email, password } = request.body;
  console.log(request.body);

  pool.getConnection((err, con) => {
    console.log("Conection S");
    console.log("Con : ", con);

    if (!err) {
      let sql = "INSERT INTO admin (email, password) VALUES (?, ?)";
      con.query(sql, [email, password], (err, result) => {
        // con.release();
        if (!err) {
          if (result.length != 0)
            console.log("Sign in success");
          else
            console.log("Sign in failed...");
        }
      });
    }
    else
      console.log(err);
  });
}