import express from "express";
import { signUp, singInPage } from "../controller/admin.controller.js";

const router = express.Router();

router.post("/sign-up",signUp);
console.log("Admin Route Called");

router.get("/sign-up",singInPage);
export default router;